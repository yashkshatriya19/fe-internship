export const students = JSON.parse(
    localStorage.getItem("students")
) 
// ||[
//     {
//         id: 1,
//         name: "Rahul",
//         email: "rahul@gmail.com",
//         age: 21,
//         gender: "Male",
//         course: "React",
//         marks: 85,
//         grade: "B",
//         city: "Ahmedabad"
//     },
//     {
//         id: 2,
//         name: "Priya",
//         email: "priya@gmail.com",
//         age: 22,
//         gender: "Female",
//         course: "Node.js",
//         marks: 72,
//         grade: "C", 
//         city: "Surat"
//     },
//     {
//         id: 3,
//         name: "Amit",
//         email: "amit@gmail.com",
//         age: 20,
//         gender: "Male",
//         course: "JavaScript",
//         marks: 91,
//         grade: "A",
//         city: "Vadodara"
//     }
// ];
