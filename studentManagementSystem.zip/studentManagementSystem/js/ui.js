

//Render the student list
function renderStudentList() {
    const studentList = document.getElementById('studentList');
    studentList.innerHTML = '';
}

//render the student table
function renderStudentTable() {
    const studentTableBody = document.getElementById('studentTableBody');
    studentTableBody.innerHTML = '';
    const students = loadStudents();
    students.forEach(student => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${student.name}</td>
            <td>${student.email}</td>
        `;
        studentTableBody.appendChild(row);
    });
}
