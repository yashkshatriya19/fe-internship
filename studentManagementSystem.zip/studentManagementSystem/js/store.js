// Save students to localStorage
function saveStudents(students) {
    localStorage.setItem('students', JSON.stringify(students));
}

// Load students from localStorage
function loadStudents() {
    const students = localStorage.getItem('students');
    return students ? JSON.parse(students) : [];
}

// Clear students from localStorage
function clearStudents() {
    localStorage.removeItem('students');
}

