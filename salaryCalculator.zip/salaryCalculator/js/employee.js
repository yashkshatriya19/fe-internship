export const employees = [
    {
        ID: 1,
        name: "John",
        department: "IT",
        designation: "Software Engineer",
        salary: 50000,
        experience: 5,
        rating: 4.5,
        hra: 10000,
        da: 5000,
        bonus: 5000,
        grossSalary: 70000,
        tax: 7000,
        deductions: 1000,
        netSalary: 62000
    },

    {
        ID: 2,
        name: "Sarah",
        department: "Marketing",
        designation: "Marketing Manager",
        salary: 60000,
        experience: 3,
        rating: 4.2,
        hra: 12000,
        da: 6000,
        bonus: 6000,
        grossSalary: 84000,
        tax: 8400,
        deductions: 1200,
        netSalary: 74400
    },

    {
        ID: 3,
        name: "David",
        department: "Finance",
        designation: "Finance Manager",
        salary: 70000,
        experience: 4,
        rating: 4.8,
        hra: 14000,
        da: 7000,
        bonus: 10500,
        grossSalary: 101500,
        tax: 10150,
        deductions: 1400,
        netSalary: 89950
    },

    {
        ID: 4,
        name: "Michael",
        department: "HR",
        designation: "HR Manager",
        salary: 80000,
        experience: 5,
        rating: 4.5,
        hra: 16000,
        da: 8000,
        bonus: 8000,
        grossSalary: 112000,
        tax: 11200,
        deductions: 1600,
        netSalary: 99200
    },

    {
        ID: 5,
        name: "Emily",
        department: "Sales",
        designation: "Sales Manager",
        salary: 90000,
        experience: 3,
        rating: 4.2,
        hra: 18000,
        da: 9000,
        bonus: 9000,
        grossSalary: 126000,
        tax: 12600,
        deductions: 1800,
        netSalary: 111600
    }
];