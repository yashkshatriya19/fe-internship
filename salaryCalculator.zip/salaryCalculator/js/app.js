import { employees } from './employee.js';

const form = document.getElementById('form');

form.addEventListener('submit', function(event){
    console.log("Running");
    
    event.preventDefault();
    const name = document.getElementById('name').value.trim();
    const ID = document.getElementById('ID').value.trim();
    const department = document.getElementById('department').value.trim();
    const designation = document.getElementById('designation').value.trim();
    let salary = document.getElementById('salary').value;
    const experience = document.getElementById('experience').value;
    let rating = document.getElementById('rating').value;
    // Validation
    let isValid = true;
    
    // Name validation
    const nameError = document.getElementById('nameError');
    if(name ===""){
        nameError.textContent = "Name cannot be empty";
        isValid = false;
    } else if(name.length < 3){
        nameError.textContent = "Name must be at least 3 characters long";
        isValid = false; 
    } else if(name.length > 20){
        nameError.textContent = "Name cannot be longer than 20 characters";
        isValid = false;
    } 
    else if(!/^[a-zA-Z\s]+$/.test(name)){
       nameError.textContent = "Name can only contain letters and spaces";
        isValid = false;
    }
    else{
        nameError.textContent = "";
    }

    // ID validation
    const idError = document.getElementById('idError');
    if(ID === ""){
        idError.textContent = "ID cannot be empty";
        isValid = false;
    }
    else if(!/^[0-9]+$/.test(ID)){
        idError.textContent = "ID must be a number";
        isValid = false;
    }
    else{
        idError.textContent = "";
    }

    // Department validation
    const departmentError = document.getElementById('departmentError');
    if(department === ""){
        departmentError.textContent = "Please select a department";
        isValid = false;
    }else{
        departmentError.textContent = "";
    }

    // Designation validation
    const designationError = document.getElementById('designationError');
    if(designation === ""){
        designationError.textContent = "Please enter a designation";
        isValid = false;
    }else if (!/^[a-zA-Z\s]+$/.test(designation)){
        designationError.textContent = "Designation can only contain letters and spaces";
        isValid = false;
    }
    else{
        designationError.textContent = "";
    }

    // Salary validation
    const salaryError = document.getElementById('salaryError');
    if (salary === ""){
        salaryError.textContent = "Please enter a salary";
        isValid = false;
    }else if(isNaN(salary) || salary < 0){
        salaryError.textContent = "Salary must be a number greater than 0";
        isValid = false;
    }
    else{
        salaryError.textContent = "";
    }

    // Experience validation
    const experienceError = document.getElementById('experienceError');
    if (experience === ""){
        experienceError.textContent = "Please enter an experience";
        isValid = false;
    } else if(isNaN(experience) || experience < 0){
        experienceError.textContent = "Experience must be a number greater than 0";
        isValid = false;
    }
    else{
        experienceError.textContent = "";
    }

    // Rating validation
    const ratingError = document.getElementById('ratingError');
    if (rating === ""){
        ratingError.textContent = "Please enter a rating";
        isValid = false;
    } else if(isNaN(rating) || rating < 0 || rating > 5){
        ratingError.textContent = "Rating must be a number between 0 and 5";
        isValid = false;
    }
    else{
        ratingError.textContent = "";
    }
    salary = Number(salary);
    rating = Number(rating);
    const hra = calculateHra(salary);
    const da = calculateDa(salary);
    const bonus = calculateBonus(salary,rating);
    const grossSalary = calculateGrossSalary(salary,hra,da,bonus);
    const tax = calculateTax(grossSalary);
    const deductions = calculateDeductions(salary);
    const netSalary = calculateNetSalary(grossSalary,tax,deductions);
    if(isValid){
        const employee = {
            id: Date.now(),
            name: name,
            ID: ID,
            department: department,
            designation: designation,
            salary: salary,
            experience: experience,
            rating: rating,
            hra: hra,
            da: da,
            bonus: bonus,
            grossSalary: grossSalary,
            tax: tax,
            deductions: deductions,
            netSalary: netSalary,

        };
        employees.push(employee);
        form.reset();
        // localStorage.setItem("employees", JSON.stringify(employees));
        renderEmployeeList(employees);
    }
});

function calculateHra(salary){
    return salary * 0.20;
}

function calculateDa(salary){
    return salary * 0.10;
}

function calculateBonus(salary,rating){
    if(rating >= 4.8){
        return salary * 0.20;
    }
    else if(rating >= 4){
        return salary * 0.15;
    }
    else if(rating >= 3){
        return salary * 0.10;
    }
    else if(rating >= 2){
        return salary * 0.05;
    }
    else if(rating >= 1){
        return salary * 0.02;
    }
    else{
        return 0;
    }
}
function calculateGrossSalary(salary,hra,da,bonus){
    return salary + hra + da + bonus;
}    

function calculateTax(grossSalary){
    return grossSalary * 0.1;
}

function calculateDeductions(salary){
    return salary * 0.02;
}

function calculateNetSalary(grossSalary,tax,deductions){
    return grossSalary - tax - deductions;
}

function renderEmployeeList(employees) {
    const employeeList = document.getElementById('employeesBody');
    employeeList.innerHTML = '';
    employees.forEach(employee => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${employee.name}</td>
            <td>${employee.ID}</td>
            <td>${employee.department}</td>
            <td>${employee.designation}</td>
            <td>${employee.salary}</td>
            <td>${employee.experience}</td>
            <td>${employee.rating}</td>
            <td>
                <button class="edit-btn" data-id="${employee.id}">Edit</button>
                <button class="delete-btn" data-id="${employee.id}">Delete</button>
            </td>
            <td><button class="info-btn" data-id="${employee.id}">Info</button></td>
        `;
        employeeList.appendChild(row);  
    });
}
renderEmployeeList(employees);
